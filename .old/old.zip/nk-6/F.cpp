#include <bits/stdc++.h>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long
#define NODEA 1000001

int max_depth = 0;

vector<int> route(NODEA); // 图
vector<int> dp(NODEA, 0); // 记录深度
vector<int> vis(NODEA, 0); // 访问记录

void dfs(int start) {
    if (vis[start] == 2) return;

    if (vis[start] == 1) {
        dp[start] = 0;
        return;
    }

    vis[start] = 1; // ing

    int next = route[start];

    if (dp[next] == 0) dfs(next);
    dp[start] = 1 + dp[next];

    vis[start] = 2; // finish 这个点和其他的都扫完了

    if (dp[start] > max_depth) {
        max_depth = dp[start];
    }
}

void slove() {
    int N; cin >> N;

    for (int i = 1; i <= N; i++) {
        cin >> route[i];
    }

    for (int i = 1; i <= N; i++) {
        if (dp[i] == 0) dfs(i);
    }

    cout << max_depth << endl;
}