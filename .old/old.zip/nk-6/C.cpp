#include <bits/stdc++.h>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long
#define MOD 1000000007
void slove() { 
    int N, M, H;
    cin >> N >> M >> H;

    int sum = 0;
    for (int i = 0; i < H; i++) {
        int xi, yi, zi;
        cin >> xi >> yi >> zi;

        for (int j = 1; j <= M; j++) {
            sum += (zi * (xi + j));
        }
        for (int j = 1; j <= N; j++) {
            sum += (zi * (yi + j));
        }
        
        sum -= zi * (xi + yi);
        sum %= MOD;
    }

    cout << sum << endl;
}