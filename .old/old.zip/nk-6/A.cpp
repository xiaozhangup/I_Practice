#include <bits/stdc++.h>

using namespace std;

void slove();

int main() {
    slove();
}

#define int long long
void slove() { 
    int a, b, c;
    cin >> a >> b >> c;

    if (a + b > c && a + c > b && b + c > a) {
        if (a == b && b == c) {
            cout << "Yes" << endl;
            printf("%.2f %.2f %.2f", (double)a / 2.0 , (double)a / 2.0 , (double)a / 2.0);
            return;
        }

        float x = (a + b - c) / 2.0;
        if (x > 0) {
            cout << "Yes" << endl;
            vector<float> v;
            v.push_back(x);
            v.push_back((float)(a - x));
            v.push_back((float)(b - x));
            sort(v.begin(), v.end());
            printf("%.2f %.2f %.2f", v[0], v[1], v[2]);
            return;
        }

        return;
    }

    cout << "wtnl";
}