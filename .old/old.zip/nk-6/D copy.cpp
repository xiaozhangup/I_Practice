#include <bits/stdc++.h>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long

int N, K;
int A[100001];
int B[100001];

int count_ge(int x) {
    int i = 0, j = N - 1;
    int cnt = 0;
    while (i < N && j >= 0) {
        if (A[i] + B[j] >= x) {
            cnt++;
            i++;
            j--;
        } else {
            i++;
        }
    }
    return cnt;
}

void slove() {
    if (!(cin >> N >> K)) return;
    for (int i = 0; i < N; i++) cin >> A[i];
    for (int i = 0; i < N; i++) cin >> B[i];
    sort(A, A + N);
    sort(B, B + N);

    int l = 0, r = 200000000; // 可适当放宽边界
    int res = 0;
    while (l <= r) {
        int mid = l + (r - l) / 2;
        if (count_ge(mid) >= K) {
            res = mid;
            l = mid + 1;
        } else {
            r = mid - 1;
        }
    }
    cout << res << '\n';
}