#include <bits/stdc++.h>

using namespace std;

void slove();

int main() {
    slove();
}

#define int long long
void slove() { 
    int T; cin >> T;

    for (int i = 0; i < T; i++) {
        int N; cin >> N;

        int bro = 0;
        int del = 0;
        for (int j = 0; j < N; j++) {
            char c; cin >> c;
            if (c == '(') bro++;
            else if (c == ')') {
                bro--;
                if (bro < 0) {
                    del++;
                    bro = 0;
                }
            }
        }

        cout << abs(del + bro) << endl;
    }
}