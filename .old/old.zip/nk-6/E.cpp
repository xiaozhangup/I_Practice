#include <bits/stdc++.h>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long
#define MOD 1000000007
void slove() { 
    int N; cin >> N;

    vector<int> A(N); for (int i = 0; i < N; i++) cin >> A[i];
    vector<int> B(N); for (int i = 0; i < N; i++) cin >> B[i];

    
}