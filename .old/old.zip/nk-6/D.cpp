#include <bits/stdc++.h>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long

int N, K;
int A[100001];
int B[100001];

int count(int x) {
    int cc = 0, j = N - 1;

    for (int i = 0; i < N; i++) {
        while (j >= 0 && A[i] + B[j] >= x) { // 直接对着答案找pair数
            j--;
        }
        cc += N - 1 - j;
    }

    return cc;
}

void slove() { 
    cin >> N >> K;

    for (int i = 0; i < N; i++) {
        cin >> A[i];
    }
    for (int i = 0; i < N; i++) {
        cin >> B[i];
    }
    
    sort(A, A + N);
    sort(B, B + N);

    int l = 2, r = 2e8;
    int res = 0;

    while (l <= r) {
        int mid = l + (r - l) / 2;
        if (count(mid) >= K) {
            res = mid;
            l = mid + 1;
        } else {
            r = mid - 1;
        }
    }

    cout << res << endl;
}