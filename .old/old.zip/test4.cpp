#include <cstdio>
#include <iostream>
#include <vector>

using namespace std;

struct Range
{
    long long start;
    long long end;

    Range(long long a, long long b)
    {
        start = a;
        end = b;
    }

    bool inRange(Range range)
    {
        if ((range.start < start && end < range.end) || (start < range.start && range.end < end))
        {
            return false;
        }

        if (end < range.start || start > range.end)
        {
            return false;
        }

        return true;
    }
};

int main()
{
    int T;
    scanf("%d", &T);
    for (int i = 0; i < T; i++)
    {
        int n;
        scanf("%d", &n);
        vector<Range> ranges;
        bool fl = false;

        long long min = 0, max = 0;
        for (int i = 0; i < n; i++)
        {
            long long a, b;
            scanf("%lld%lld", &a, &b);

            if (i != 0)
            {
                if (b < min || a > max)
                {
                    fl = true;
                    break;
                }
            }

            Range rrr = Range(a, b);
            for (Range rrrr : ranges)
            {
                if (!rrrr.inRange(rrr))
                {
                    fl = true;
                    break;
                }
            }

            if (a < min)
                min = a;
            if (b > max)
                max = b;
            ranges.push_back(rrr);
        }

        if (fl)
        {
            printf("No\n");
        }
        else
        {
            printf("Yes\n");
        }
    }
}