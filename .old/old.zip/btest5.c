#include <stdio.h>
#include <string.h>

char str[5][20];

void sort() {
    while (1)
    {
        int moved = 0;
        for (int i = 0; i < 4; i++) {
            if (strcmp(str[i], str[i + 1]) > 0) {
                char temp[20];
                strcpy(temp, str[i]);
                strcpy(str[i], str[i + 1]);
                strcpy(str[i + 1], temp);
                moved = 1;
            }
        }

        if (!moved) break;
    }
}

int main() {
    for (int i = 0; i < 5; i++) {
        scanf("%s", str[i]);
    }
    sort();

    for (int i = 0; i < 5; i++) {
        printf("%s\n", str[i]);
    }
}