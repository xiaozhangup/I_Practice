#include <cstdio>
#include <iostream>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long

//        n   x
int cache[10][10];

int hermite(int n, int x) {
    if (n == 0) {
        return 1;
    }

    if (n == 1) {
        return 2 * x;
    }

    int ced = cache[n][x];
    if (ced > 0) {
        return ced;
    }

    int res = 2 * x * hermite(n - 1, x) - 2 * (n - 1) * hermite(n - 2, x);
    cache[n][x] = res;
    return res;
}

void slove() {
    int n, x;
    cin >> n >> x;
    cout << hermite(n, x);
}