#include <cstdio>
#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
using namespace std;

int sum(vector<int> vec, int start, int amount)
{
    int res = 0;
    for (int i = 0; i < amount; i++)
    {
        res += vec[start + i];
    }
    return res;
}

int sumA(vector<int> vec, int amount)
{
    int res = 0;
    for (int i = 0; i < amount; i++)
    {
        res += vec[i];
    }
    return res;
}

int sumB(vector<int> vec, int amount)
{
    int res = 0;
    for (int i = 0; i < amount; i++)
    {
        res += vec[vec.size() - 1 - i];
    }
    return res;
}

int findMiddle(vector<int> vec)
{
    for (int i = 1; i < vec.size(); i++)
    {
        int left = sumA(vec, i);
        int right = sumB(vec, vec.size() - i);
        if (left - right > 0)
            return i;
    }
    return vec.size() / 2;
}

int cost(vector<int> vec)
{
    if (vec.size() <= 1) return 0;
    if (vec.size() == 2) return vec[0] + vec[1];

    int mid = findMiddle(vec);
    if (mid <= 0 || mid >= vec.size())
        return sumA(vec, vec.size());

    return cost(vector<int>(vec.begin(), vec.begin() + mid)) +
           cost(vector<int>(vec.begin() + mid, vec.end()));
}

int main()
{
    int N, base = 0;
    cin >> N;

    vector<int> vec;
    for (int i = 0; i < N; i++)
    {
        int x;
        cin >> x;
        vec.push_back(x);
        base += x;
    }
    sort(vec.begin(), vec.end());

    cout << cost(vec) + base << endl;
}