#include <cstdio>
#include <iostream>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long

int findColor(int index, int total, int pre_c) {
    if (index == 1) return 1;

    if (total == total) {
        if (pre_c == 1) {
            return 2;
        } else {
            return 1;
        }
    }

    if (pre_c == 1) {
        return findColor(index + 1, total, 2) + findColor(index + 1, total, 3);
    } else if (pre_c == 2) {
        return findColor(index + 1, total, 1) + findColor(index + 1, total, 3);
    } else {
        return findColor(index + 1, total, 1) + findColor(index + 1, total, 2);
    }
}

void slove() {
    int N;
    while (cin >> N)
    {
        cout << findColor(0, N, 1) * 3 << endl;
    }

}