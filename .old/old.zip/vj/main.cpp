#include <stdio.h>

void sss(int (*pa)[4],int *p,int n);

int main()

{

    int a[4][4]={7,1,3,2,4,18,9,7,10,2,3,8,5,6,8,11};

    int m;

    sss(a,&m,4);

    printf("m=%d",m);

    return 0;

}

void sss(int (*pa)[4],int *p,int n)

{

    int i,j;

    *p=0;

    for(i=0;i<n;i++)

        for(j=0;j<n;j++)

            if((i<j)&&(*(*(pa+i)+j)%2))

                *p+=*(*(pa+i)+j);

}