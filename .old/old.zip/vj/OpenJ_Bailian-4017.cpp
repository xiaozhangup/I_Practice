#include <bits/stdc++.h>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long

int cache[40] {0};

int fib(int n) {
    if (n == 1 || n == 2) {
        return 1;
    }

    if (cache[n] > 0) {
        return cache[n];
    }

    int res = fib(n - 1) + fib(n - 2);
    cache[n] = res;
    return res;
}

void slove() {
    int N;
    while (cin >> N) {
        if (N == 1) {
            cout << 1 << endl;
            continue;
        }
        if (N == 2) {
            cout << 2 << endl;
            continue;
        }
        cout << fib(N + 1) << endl;
    }
}