#include <bits/stdc++.h>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long

map<int, int> cache;
int fib(int n) {
    if (n == 1 || n == 2) {
        return 1;
    }

    return fib(n - 1) + fib(n - 2);
}

void slove() {
    int n; cin >> n;

    for (int i = 0; i < n; i++) {
        int nu; cin >> nu;
        cout << fib(nu) << endl;
    }
}