#include <cstdio>
#include <vector>
#include <algorithm>

using namespace std;

struct Range
{
    long long start;
    long long offset;
    long long index;

    Range(long long a, long long b, long long c)
    {
        start = a;
        offset = b - a;
        index = c;
    }
};

int main()
{
    long long n;
    int q;
    scanf("%lld%d", &n, &q);

    vector<Range> ranges;
    for (long long i = 1; i <= n; i++) // 数据录入
    {
        long long a, b;
        scanf("%lld%lld", &a, &b);
        ranges.push_back(Range(a, b, i));
    }

    sort(ranges.begin(), ranges.end(), [](Range a, Range b) {
        return a.start < b.start;
    });
    for (int i = 0; i < q; i++) // 询问
    {
        long long x;
        int ed = 0;
        scanf("%lld", &x);

        for (long long j = 0; j < n; j++)
        {
            if (ranges[j].start <= x && x <= ranges[j].start + ranges[j].offset)
            {
                printf("%lld\n", ranges[j].index);
                ed = 1;
                break;
            }
        }
        if (!ed)
        {
            printf("-1\n");
        }
    }
}