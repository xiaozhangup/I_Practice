#include<stdio.h>
int main()
{
    char ch;
    ch=getchar();
    switch(ch)
    {
        case 'a': printf("a=%c",ch) ;
        default: printf("***");
        case 'b': printf("b=%c",ch);
        case 'c': printf("c=%c",ch);
    }
    return 0;
}