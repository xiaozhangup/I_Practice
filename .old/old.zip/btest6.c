#include <stdio.h>
#include <string.h>

int main() {
    int sum = 0;
    char str[200];
    scanf("%s", str);

    while (1)
    {
        if (str[sum] == '\0') break;
        sum++;
    }
    
    printf("%d\n", sum);
}