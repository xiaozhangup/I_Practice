#include <stdio.h>

char words[][20] = {
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
};

int main() {
    int m; scanf("%d", &m);
    char *sd = words[m - 1];
    printf("%s ", sd);
    printf("%c", sd[0]);
}