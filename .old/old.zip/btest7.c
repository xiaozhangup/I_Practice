#include <stdio.h>

#define N 3  // 矩阵维度

// 声明使用元素指针（指向单个元素的指针）实现转置
void transMatrix(int (*matrix)[N]); 
int main() {
    int A[N][N];
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            scanf("%d", &A[i][j]);
        }
    }

    // 使用元素指针转置
    transMatrix((int (*)[N])A);

    return 0;
}

void transMatrix(int (*matrix)[N]) {
    int i, j, temp;
    for (i = 0; i < N; i++) {
        for (j = i + 1; j < N; j++) {
            temp = *(*(matrix + i) + j);
            *(*(matrix + i) + j) = *(*(matrix + j) + i);
            *(*(matrix + j) + i) = temp;
        }
    }

    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            printf("%d ", *(*(matrix + i) + j));
        }
        printf("\n");
    }
}