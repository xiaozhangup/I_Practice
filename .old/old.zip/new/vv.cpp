#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    while (true) {
        int n;
        cin >> n;
        if (n == 0) break;

        map<string, int> id;
        vector<pair<int,int>> matches;
        int idx = 0;

        for (int i = 0; i < n; i++) {
            string a, b;
            cin >> a >> b;
            if (!id.count(a)) id[a] = idx++;
            if (!id.count(b)) id[b] = idx++;
            matches.push_back({id[a], id[b]});
        }

        int sz = idx;
        vector<vector<bool>> G(sz, vector<bool>(sz, false));

        for (auto &p : matches) {
            G[p.first][p.second] = true;
        }

        // Floyd-Warshall 传递闭包
        for (int k = 0; k < sz; k++)
            for (int i = 0; i < sz; i++)
                for (int j = 0; j < sz; j++)
                    if (G[i][k] && G[k][j])
                        G[i][j] = true;

        // 检查三元循环
        bool hasCycle = false;
        for (int i = 0; i < sz && !hasCycle; i++)
            for (int j = 0; j < sz && !hasCycle; j++)
                for (int k = 0; k < sz && !hasCycle; k++)
                    if (i != j && j != k && i != k)
                        if (G[i][j] && G[j][k] && G[k][i])
                            hasCycle = true;

        if (hasCycle) {
            cout << "No\n";
            continue;
        }

        // 找入度为0的节点（没人能打败他）
        int champ = -1;
        for (int i = 0; i < sz; i++) {
            bool lose = false;
            for (int j = 0; j < sz; j++) {
                if (G[j][i]) {
                    lose = true;
                    break;
                }
            }
            if (!lose) {
                if (champ != -1) champ = -2; // 多个冠军
                else champ = i;
            }
        }

        if (champ >= 0) cout << "Yes\n";
        else cout << "No\n";
    }

    return 0;
}
