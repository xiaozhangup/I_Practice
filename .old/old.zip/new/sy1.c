#include <stdio.h>
#include <string.h>

struct student
{
    long long id;
    char name[20];
    float grade[3];
    float average;
};

struct student build(long long id, char name[], float g1)
{
    struct student s;
    s.id = id;
    strcpy(s.name, name);
    s.grade[0] = g1;
    return s;
}

void input(struct student s[], int n);
float average1(struct student s[], int n);
float average(struct student s[], int n);
int max(struct student s[], int n);

int N;

int main()
{
    struct student stu[10];
    scanf("%d", &N);
    input(stu, N);

    for (int i = 0; i < N; i++)
    {
        average1(stu, i);
    }
    float avg = average(stu, N);

    printf("from highest to lowest:\n");
    for (int i = 0; i < N - 1; i++)
    {
        for (int j = i + 1; j < N; j++)
        {
            if (stu[i].average < stu[j].average)
            {
                struct student temp = stu[i];
                stu[i] = stu[j];
                stu[j] = temp;
            }
        }
    }
    for (int i = 0; i < N; i++)
    {
        printf(
            "%lld %s %.2f\n",
            stu[i].id,
            stu[i].name,
            stu[i].grade[0]
        );
    }

    // 不及格的名称
    printf("\nInformation of students who failed:\n");
    for (int i = 0; i < N; i++)
    {
        if (stu[i].grade[0] < 60)
        {
            printf("%s\n", stu[i].name);
        }
    }

    // 输出低于平均分的记录
    printf("\nInformation of students with scores below the average:\n");
    for (int i = 0; i < N; i++)
    {
        if (stu[i].average < avg)
        {
            printf(
                "%lld %s %.2f\n",
                stu[i].id,
                stu[i].name,
                stu[i].grade[0]
            );
        }
    }

    return 0;
}

float average1(struct student s[], int n)
{
    s[n].average = s[n].grade[0];
    return s[n].average;
}

float average(struct student s[], int n)
{
    float sum = 0.0f;
    for (int i = 0; i < n; i++)
    {
        sum += average1(s, i);
    }
    return sum / (float)n;
}

int max(struct student s[], int n)
{
    int index = 0;
    float max_avg = s[0].average;
    for (int i = 1; i < n; i++)
    {
        if (s[i].average > max_avg)
        {
            max_avg = s[i].average;
            index = i;
        }
    }
    return index;
}

void input(struct student s[], int n)
{
    while (n--)
    {
        long long id;
        float grade[3];
        char name[20];

        scanf("%lld %s %f", &id, name, &grade[0]);
        s[n] = build(id, name, grade[0]);
    }
}