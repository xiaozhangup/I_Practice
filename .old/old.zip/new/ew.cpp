#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <cstdio>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <unordered_map>
#include <unordered_set>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long

void slove() {

}