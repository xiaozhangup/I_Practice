#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <cstdio>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <unordered_map>
#include <unordered_set>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long
#define MOD 1000000007

void slove() {
    int t; cin >> t;
    while(t--) {
        int n, m; cin >> n >> m;
        map<int, set<int>> road;
        for (int i = 0; i < m; i++) {
            int a, b; cin >> a >> b;
            road[a].insert(b);
            road[b].insert(a);
        }

        int sum = 0;
        while(true) {
            bool modified = false;
            for (auto &mp : road) {
                int id = mp.first;
                if (!mp.second.empty()) {
                    for (int iid : mp.second) {
                        road[iid].erase(id);
                    }
                    sum += mp.second.size();
                    modified = true;
                    mp.second.clear();
                }
            }
            
            if (!modified) break;
        }

        cout << sum << "\n";
    }
}