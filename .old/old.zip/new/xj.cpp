#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <cstdio>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <unordered_map>
#include <unordered_set>
#include <sstream>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define ll long long

map<int, vector<int>> g;

vector<int> topo_sort(int n) {
    vector<int> indeg(n+1, 0), res;
    for (int u = 1; u <= n; u++)
        for (int v : g[u]) indeg[v]++;
    queue<int> q; // 最小优先
    for (int i = 1; i <= n; i++) if (indeg[i] == 0) q.push(i);

    bool unique = true;
    while (!q.empty()) {
        if (q.size() > 1) unique = false;  // 多个选择，序列不唯一
        int u = q.front(); q.pop();
        res.push_back(u);
        for (int v : g[u]) {
            indeg[v]--;
            if (indeg[v] == 0) q.push(v);
        }
    }
    return res; // 如果 res.size() < n，则存在环
}

void slove() {
    int N, M;
    while(cin >> N >> M) {
        if (N == 0 && M == 0) break;
        
        g.clear();
        for (int i = 0; i < M; i++) {
            int a, b; cin >> a >> b;
            g[a].push_back(b);
        }


        auto res = topo_sort(N);
        for (int i = 0; i < res.size(); i++) {
            if (i) cout << " ";
            cout << res[i];
        }
        cout << "\n";
    }
}