#include <iostream>
#include <vector>
#include <string>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <cstdio>
#include <algorithm>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);

    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long

void slove() {
    cin >> n >> m >> s;
    for (int i = 0; i < n; i++) {
        int x, y; cin >> x >> y;
    }
    for (int i = 0; i < m; i++) {
        int x, y; cin >> x >> y;
    }

}