#include <stdio.h>
#include <string.h>
#define STR_MAX_LEN 100
// 函数声明
void reverse(char s[]);

int main() {
    char str[STR_MAX_LEN];

    // 输入字符串
    fgets(str, sizeof(str), stdin);
    // 去除fgets读取的换行符
    str[strcspn(str, "\n")] = '\0';
    
    
    char output[STR_MAX_LEN];
    int index = 0;
    int i;
    for (i = strlen(str) - 1; i >= 0; i--) {
        output[index] = str[i];
        index++;
    }
    output[index] = '\0';
    printf("%s", output);
    return 0;
}

// 函数定义：反转字符串
void reverse(char s[]) {
}