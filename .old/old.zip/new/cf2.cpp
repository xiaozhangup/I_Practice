#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <cstdio>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <unordered_map>
#include <unordered_set>
#include <sstream>
// #include <bits/stdc++.h>

using namespace std;

void slove();

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int T = 1;
    cin >> T;
    while (T--) {
        slove();
    }
}

// #define ll long long

void slove() {
    int c; cin >> c;
    string str; cin >> str;

    int min_ = 4;
    bool any_2025 = false;
    for (int i = 3; i < c; i++) {
        int mm = 4;
        char l0 = str[i];
        char l1 = str[i - 1];
        char l2 = str[i - 2];
        char l3 = str[i - 3];

        if (l3 == '2') mm--;
        if (l2 == '0') mm--;
        if (l1 == '2') mm--;
        if (l0 == '5') mm--;
        if (mm == 0) any_2025 = true;
    }

    if (!any_2025) {
        cout << "0\n";
        return;
    }

    for (int i = 3; i < c; i++) {
        int mm = 4;
        char l0 = str[i];
        char l1 = str[i - 1];
        char l2 = str[i - 2];
        char l3 = str[i - 3];

        if (l3 == '2') mm--;
        if (l2 == '0') mm--;
        if (l1 == '2') mm--;
        if (l0 == '6') mm--;
        min_ = min(min_, mm);
    }
    
    cout << min_ << "\n";
}