#include <stdio.h>
#include <string.h>

struct student
{
    long long id;
    char name[20];
    float grade[10];

    struct student *next;
};
struct student *header;

int main()
{

    for (int i = 0; i < 10; i++)
    {
        struct student s;
        s.next = NULL;

        scanf("%lld %s %f %f %f", &s.id, s.name, &s.grade[0]);
        if (header == NULL)
        {
            header = &s;
        }
        else
        {
            struct student *p = header;
            while (p->next != NULL)
            {
                p = p->next;
            }
            p->next = &s;
        }
    }
}

void loopChain()
{
    struct student *p = header;
    while (p != NULL)
    {
        printf("%lld %s %.2f\n", p->id, p->name, p->grade[0]);
        p = p->next;
    }
}

void insertAfter(long long id, struct student newStu)
{
    struct student *p = header;
    while (p != NULL)
    {
        if (p->id == id)
        {
            newStu.next = p->next;
            p->next = &newStu;
            return;
        }
        p = p->next;
    }
}

void deleteAfter(long long id)
{
    struct student *p = header;
    while (p != NULL)
    {
        if (p->id == id)
        {
            struct student *del = p->next;
            if (del != NULL)
            {
                p->next = del->next;
                free(del);
            }
            return;
        }
        p = p->next;
    }
}