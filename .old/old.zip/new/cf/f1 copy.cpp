#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <cstdio>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <unordered_map>
#include <unordered_set>
#include <sstream>
// #include <bits/stdc++.h>

using namespace std;

void slove();

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int T = 1;
    cin >> T;
    while (T--) {
        slove();
    }
}

#define int long long

struct Jump {
    int length;
    int back;
    int limit;

    int offsetl, offsetr;

    Jump(int a, int b, int c) {
        length = a;
        back = c;
        limit = b;

        offsetl = limit * c * -1;
    }

    int offsetLeft() {
        return offsetl;
    }

    int offsetRight(int n) {
        int ba = min(n, limit);
        return ba * -1 * back + n * length;
    }
};

void slove() {
    //     target
    int n, x, cur = 0;
    cin >> n >> x;

    vector<Jump> jmps;
    for (int i = 0; i < n; i++) {
        int a, b, c;
        cin >> a >> b >> c;
        jmps.push_back(Jump(a, b, c));
    }

    int offs = x - cur;

    int min_ = 10e9;
    for (auto &jup : jmps) {
        int gew = jup.length - jup.back;
        if (gew > 0) {
            int tims = x / gew;
            if (tims <= jup.limit) {
                min_ = min(min_, tims);
                continue;
            }
        }

        int total = jup.limit * jup.back + x;
        int amo = total / jup.length  + jup.limit;
        min_ = min(min_, amo);
    }

    cout << min_ << "\n";
}