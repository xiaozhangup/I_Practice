#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <cstdio>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <unordered_map>
#include <unordered_set>
#include <sstream>
// #include <bits/stdc++.h>

using namespace std;

void slove();

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int T = 1;
    cin >> T;
    while (T--) {
        slove();
    }
}

#define ll long long

void slove() {
    int n, h, l;
    cin >> n >> h >> l;

    // vector<vector<int>> map(h, vector<int>(l, 0));
    vector<int> nums;
    for (int i = 0; i < n; i++) {
        int a; cin >> a;
        if (a > h && a > l) continue;
        nums.push_back(a);
    }

    sort(nums.begin(), nums.end());
    int maxl = max(h, l);
    int minl = min(h, l);
    int count = 0;
    int si = nums.size();
    for (int i = 1; i <= si / 2; i++) {
        int mil = nums[i - 1];
        int mal = nums[si - i];

        if (mil > minl || mal > maxl) break;
        count++;
    }

    cout << count << "\n";
}