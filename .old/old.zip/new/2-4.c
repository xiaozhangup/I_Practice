#include <stdio.h>

void slove();

int main() {
    slove();
}

#define int long long

int max(int a, int b) {
    return a > b ? a : b;
}

int min(int a, int b) {
    return a < b ? a : b;
}

int digit(int n ,int k) {
    for (int i = 0; i < k - 1; i++) {
        n /= 10;
    }

    if (n == 0) {
        return -1;
    }

    return n - (n / 10 * 10);
}

void slove() {
    int n,k;
    scanf("%d%d",&n,&k);

    for (int i = 0; i < k - 1; i++) {
        n /= 10;
    }

    printf("%d", n - (n / 10 * 10));
}