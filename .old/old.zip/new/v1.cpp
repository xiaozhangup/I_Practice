#include <iostream>
#include <vector>
using namespace std;

int main() {
    // 背包容量
    int W = 10;

    // 物品数量
    int n = 3;

    // 每件物品的重量（索引从 1 开始方便理解）
    vector<int> weight = {0, 2, 3, 4};

    // 每件物品的价值
    vector<int> value = {0, 3, 4, 5};

    // dp[i][w] = 前 i 件物品，容量为 w 的最大价值
    vector<vector<int>> dp(n + 1, vector<int>(W + 1, 0));

    // 开始填表
    for (int i = 1; i <= n; i++) {       // 遍历每件物品
        for (int w = 1; w <= W; w++) {   // 遍历每个容量
            if (w >= weight[i]) {
                // 可以放下第 i 件物品：选或者不选，看哪个值大
                dp[i][w] = max(dp[i-1][w], dp[i-1][w - weight[i]] + value[i]);
            } else {
                // 放不下第 i 件物品，只能不选
                dp[i][w] = dp[i-1][w];
            }
            // 输出一下每步的决策（可选）
            // cout << "dp[" << i << "][" << w << "] = " << dp[i][w] << endl;
        }
    }

    // 最终结果：最多能装的价值
    cout << "背包最大价值 = " << dp[n][W] << endl;

    return 0;
}
