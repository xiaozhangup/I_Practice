#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <cstdio>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <unordered_map>
#include <unordered_set>
#include <sstream>
// #include <bits/stdc++.h>

using namespace std;

void slove();

struct Student
{
    int id;
    string name;
    float sc1;
    float sc2;
    float sc3;

    Student(int i, string n, float s1, float s2, float s3) {
        id = i;
        name = n;
        sc1 = s1;
        sc2 = s2;
        sc3 = s3;
    }
};

vector<Student> students;

int sum = 0;

int main() {
    // ios::sync_with_stdio(false);
    // cin.tie(0);
    // cout.tie(0);

    int T = 1;
    cin >> T;
    while (T--) {
        slove();
    }

    printf("%.2f\n", (double) sum / students.size() / 3.0);

    int max_V = -1;
    vector<Student> mx_stus;
    for (auto& stu : students) {
        int total = stu.sc1 + stu.sc2 + stu.sc3;
        if (total > max_V) {
            max_V = total;
            mx_stus.clear();
            mx_stus.push_back(stu);
        } else if (total == max_V) {
            mx_stus.push_back(stu);
        }
    }
    for (auto& mx_stu : mx_stus) {
        printf("%d %s %.2f %.2f %.2f\n", mx_stu.id, mx_stu.name.c_str(), (double)mx_stu.sc1, (double)mx_stu.sc2, (double)mx_stu.sc3);
    }
}

#define int long long

void slove() {
    int id;
    float sc1, sc2, sc3;
    string name;
    cin >> id >> name >> sc1 >> sc2 >> sc3;
    sum += sc1 + sc2 + sc3;
    students.push_back({id, name, sc1, sc2, sc3});
}