#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <cstdio>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <unordered_map>
#include <unordered_set>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long

int max(int a, int b) {
    return a > b ? a : b;
}

int min(int a, int b) {
    return a < b ? a : b;
}

int jc(int i) {
    int res = i;
    for (int j = 1; j < i; j++) {
        res *= (i - j);
    }

    return res;
}

int com(int x, int n) {
    return jc(x) / jc(n) / jc(x - n);
}

int n, m;
int _time__ = __LONG_LONG_MAX__;
vector<vector<int>> map_j;
vector<vector<int>> map_o;
vector<vector<int>> vis;

void dfs(int x, int y, int sec) {
    if (x == m - 1 && y == n - 1) {
        if (_time__ > sec) {
            _time__ = sec;
        }
        return;
    }
    if (sec & 1) { // j
        if (x + 1 < n) {
            if (map_j[x + 1][y] == 0 && vis[x + 1][y] == 0) {
                vis[x + 1][y] = 1;
                dfs(x + 1, y, sec + 1);
                vis[x + 1][y] = 0;
            }
        }
        if (x - 1 >= 0) {
            if (map_j[x - 1][y] == 0 && vis[x - 1][y] == 0) {
                vis[x - 1][y] = 1;
                dfs(x - 1, y, sec + 1);
                vis[x - 1][y] = 0;
            }
        }
        if (y + 1 < m) {
            if (map_j[x][y + 1] == 0 && vis[x][y + 1] == 0) {
                vis[x][y + 1] = 1;
                dfs(x, y + 1, sec + 1);
                vis[x][y + 1] = 0;
            }
        }
        if (y - 1 >= 0) {
            if (map_j[x][y - 1] == 0 && vis[x][y - 1] == 0) {
                vis[x][y - 1] = 1;
                dfs(x, y - 1, sec + 1);
                vis[x][y - 1] = 0;
            }
        }
    } else { // o
        if (x + 1 < n) { 
            if (map_o[x + 1][y] == 0 && vis[x + 1][y] == 0) {
                vis[x + 1][y] = 1;
                dfs(x + 1, y, sec + 1);
                vis[x + 1][y] = 0;
            }
        }
        if (x - 1 >= 0) { 
            if (map_o[x - 1][y] == 0 && vis[x - 1][y] == 0) {
                vis[x - 1][y] = 1;
                dfs(x - 1, y, sec + 1);
                vis[x - 1][y] = 0;
            }
        }
        if (y + 1 < m) { 
            if (map_o[x][y + 1] == 0 && vis[x][y + 1] == 0) {
                vis[x][y + 1] = 1;
                dfs(x, y + 1, sec + 1);
                vis[x][y + 1] = 0;
            }
        }
        if (y - 1 >= 0) { 
            if (map_o[x][y - 1] == 0 && vis[x][y - 1] == 0) {
                vis[x][y - 1] = 1;
                dfs(x, y - 1, sec + 1);
                vis[x][y - 1] = 0;
            }
        }
    }
}

void slove() {
    int k; cin >> n >> m >> k;
    map_j = vector<vector<int>>(m, vector<int>(n));
    map_o = vector<vector<int>>(m, vector<int>(n));
    vis = vector<vector<int>>(m, vector<int>(n));

    while (k--) {
        int x1, y1, x2, y2;
        cin >> x1 >> y1 >> x2 >> y2;
        map_j[x1 - 1][y1 - 1] = 1;
        map_o[x2 - 1][y2 - 1] = 1;
    }

    dfs(0, 0, 1);
    cout << _time__;
}