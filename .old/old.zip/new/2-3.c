#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <cstdio>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <unordered_map>
#include <unordered_set>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long

int max(int a, int b) {
    return a > b ? a : b;
}

int min(int a, int b) {
    return a < b ? a : b;
}

const int N = 1e3;
bool vis[N + 1];

void linear_sieve() {
    vector<int> primes;
    for (int i = 2; i <= N; i++) {
        if (!vis[i]) primes.push_back(i);
        for (int p : primes) {
            if (1LL * p * i > N) break;
            vis[p * i] = true;
            if (i % p == 0) break;
        }
    }
}

void slove() {
    linear_sieve();
    int outed = 0;
    for (int i : primes) {
        outed++;
        cout << i;

        if (outed == 8) {
            cout << "\n";
            outed = 0;
        } else {
            cout << " ";
        }
    }
}