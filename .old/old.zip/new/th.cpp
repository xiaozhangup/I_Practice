#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <cstdio>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <unordered_map>
#include <unordered_set>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define ll long long

const int MAXN = 70000;
int bit_tree[MAXN];
int sz;

void update(int idx, int val) {
    for (; idx <= sz; idx += idx & -idx)
        bit_tree[idx] += val;
}

int query(int idx) {
    int sum = 0;
    for (; idx > 0; idx -= idx & -idx)
        sum += bit_tree[idx];
    return sum;
}

int find_kth(int k) {
    int l = 1, r = sz;
    int ans = -1;
    while (l <= r) {
        int mid = l + (r - l) / 2;
        if (query(mid) >= k) {
            ans = mid;
            r = mid - 1;
        } else {
            l = mid + 1;
        }
    }
    return ans;
}

void slove() {
    int n, m;
    bool first = true;
    while(cin >> n >> m) {
        if (!first) cout << "\n";
        first = false;
        
        sz = 2 * n;
        for(int i=0; i<=sz; ++i) bit_tree[i] = 0;
        for (int i = 1; i <= sz; i++) update(i, 1);
        
        vector<char> ans(sz + 1, 'G');
        int pos = 0;
        for (int i = 0; i < n; i++) {
            int remaining = 2 * n - i;
            int kill_rank = (pos + m - 1) % remaining;
            int real_idx = find_kth(kill_rank + 1);
            ans[real_idx] = 'B';
            update(real_idx, -1);
            pos = kill_rank;
        }
        
        for (int i = 1; i <= sz; i++) {
            cout << ans[i];
            if (i % 50 == 0 && i != sz) cout << "\n";
        }
        cout << "\n";
    }
}