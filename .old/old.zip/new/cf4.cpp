#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <cstdio>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <unordered_map>
#include <unordered_set>
#include <sstream>
// #include <bits/stdc++.h>

using namespace std;

void slove();

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int T = 1;
    cin >> T;
    while (T--) {
        slove();
    }
}

#define ll long long

void slove() {
    //  friend box coin
    int n,     m,  k;
    cin >> n >> m >> k;

    int count = 0;
    // box
    vector<int> ar;
    ar.resize(m);
    for (int i = 0; i < m ; i++) {
        cin >> ar[i];
    }

    for (int i = 0; i < n; i++) {
        //  box least goodprice
        int x,  y,    z;
        cin >> x >> y >> z;

        // find box
        int index = -1;
        int min_ca = 10e9;
        for (int ind = 0; ind < m; ind++) {
            int as = ar[ind];
            if (as >= x) {
                if (as - x < min_ca) {
                    min_ca = as - x;
                    index = ind;
                }
            }
        }

        if (index != -1) {
            count++;
        }

        
    }

    cout << count << "\n";
}