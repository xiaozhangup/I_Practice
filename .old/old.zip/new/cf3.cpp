#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <cstdio>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <unordered_map>
#include <unordered_set>
#include <sstream>
// #include <bits/stdc++.h>

using namespace std;

void slove();

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int T = 1;
    cin >> T;
    while (T--) {
        slove();
    }
}

#define ll long long

void slove() {
    int n; cin >> n;
    vector<int> va, vb, vc;
    // va.resize(n);
    // vb.resize(n);
    // vc.resize(n);
    for (int i = 0; i < n; i++) {
        int b; cin >> b;
        va.push_back(b);
    }

    for (int i = 0; i < n; i++) {
        int b; cin >> b;
        vb.push_back(b);
    }

    for (int i = 0; i < n; i++) {
        int c; cin >> c;
        vc.push_back(c);
    }

    int counta = 0;
    for (int ofa = 0; ofa < n; ofa++) {
        // for (int ofc = 0; ofc < n; ofc++) {
            int flag = true;
            for (int ind = 0; ind < n; ind++) {
                int ra = va[(ind + ofa) % n];
                int rb = vb[ind % n];
                // int rc = vc[(ind + ofc) % n];

                if (ra >= rb) {
                    flag = false;
                    break;
                }
            }

            if (flag) counta++;
        // }

    }

    int countb = 0;
    for (int ofc = 0; ofc < n; ofc++) {
        int flag = true;
        for (int ind = 0; ind < n; ind++) {
            int rb = vb[ind % n];
            int rc = vc[(ind + ofc) % n];

            if (rb >= rc) {
                flag = false;
                break;
            }
        }

        if (flag) countb++;
    }

    cout << 1LL * counta * countb * n << "\n";
}