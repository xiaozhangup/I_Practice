#include <stdio.h>
#include <string.h>

struct workder
{
    char name[20];
    int age;
    int worktime;
    int sex;
    int marrige;
    int grade;
    int wage;
    int tired;
};

int main()
{
    int i;
    struct workder workders[100];
    scanf("%d", &i);
    for (int k = 0; k < i; k++)
    {
        struct workder w;
        char name[20];
        int age;
        int worktime;
        scanf("%s %d %d", name, &age, &worktime);
        strcpy(w.name, name);
        w.age = age;
        w.worktime = worktime;

        char sex;
        scanf(" %c", &sex);
        if (sex == 'm')
            w.sex = 1;
        else
            w.sex = 0;

        char marrige[5];
        scanf("%s", marrige);
        if (strcmp(marrige, "true") == 0)
            w.marrige = 1;
        else
            w.marrige = 0;

        int grade;
        int wage;
        scanf("%d %d", &grade, &wage);
        w.grade = grade;
        w.wage = wage;

        char tired[5];
        scanf("%s", tired);
        if (strcmp(tired, "true") == 0)
            w.tired = 1;
        else
            w.tired = 0;

        if (w.tired) {
            w.wage += 50;
        } else {
            w.wage += w.grade * 20;
        }

        workders[k] = w;
    }

    for (int k = 0; k < i; k++)
    {
        printf(
            "%s %d %d %s %s %d %d %s\n",
            workders[k].name,
            workders[k].age,
            workders[k].worktime,
            workders[k].sex ? "m" : "f",
            workders[k].marrige ? "true" : "false",
            workders[k].grade,
            workders[k].wage,
            workders[k].tired ? "true" : "false"
        );
    }
}