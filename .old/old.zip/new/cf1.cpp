#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <cstdio>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <unordered_map>
#include <unordered_set>
#include <sstream>
// #include <bits/stdc++.h>

using namespace std;

void slove();

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int T = 1;
    cin >> T;
    while (T--) {
        slove();
    }
}

// #define ll long long

void slove() {
    int a, b;
    cin >> a >> b;
    // 0
    int indexa = 1;
    int layera = 0;
    int al = 0, bl = 0;
    while (true)
    {
        if (layera & 1) {
            al += indexa;
            if (al > a) break;
        } else {
            bl += indexa;
            if (bl > b) break;
        }
        indexa *= 2;
        layera++;
    }

    // 1
    int layerb = layera;
    indexa = 1;
    layera = 0;
    al = 0, bl = 0;
    while (true)
    {
        if (layera & 1) {
            bl += indexa;
            if (bl > b) break;
        } else {
            al += indexa;
            if (al > a) break;
        }
        indexa *= 2;
        layera++;
    }

    int res = max(layera, layerb);
    cout << res << "\n";
}