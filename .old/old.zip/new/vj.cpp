#include <bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    cin >> t;
    while (t--)
    {
        int n;
        long long res = 0;
        cin >> n;
        long long mmax = 0;
        vector<long long> a(n);
        for (int i = 0; i < n; i++)
        {
            cin >> a[i];
            if (i > 0)
            {
                res += max(a[i], a[i - 1]);
            }
            mmax = max(a[i], mmax);
        }

        res += max(a[0], a[n - 1]);
        cout << res - mmax << "\n";
    }

    return 0;
}

// #include <bits/stdc++.h>
// using namespace std;

// #define ll long long

// void solve()
// {
//     ll n;
//     cin >> n;
//     ll sum = 0;
//     ll max_element = -1;
//     vector<ll> v(n);
//     for (ll i = 0; i < n; i++)
//     {
//         cin >> v[i];
//     }
//     for (ll i = 0; i < n - 1; i++)
//     {
//         max_element = max(max_element, v[i]);
//         max_element = max(max_element, v[i + 1]);
//         sum += max(v[i], v[i + 1]);
//     }
//     sum += max(v[0], v[n - 1]);
//     cout << sum - max_element << endl;
// }

// int main()
// {
//     ios::sync_with_stdio(false);
//     cin.tie(nullptr);
//     ll t;
//     cin >> t;
//     while (t--)
//     {
//         solve();
//     }
//     return 0;
// }