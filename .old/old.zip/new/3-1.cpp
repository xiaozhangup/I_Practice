#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <cstdio>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <unordered_map>
#include <unordered_set>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long

int max(int a, int b) {
    return a > b ? a : b;
}

int min(int a, int b) {
    return a < b ? a : b;
}

int formation(int a, int n) {
    int pub = 1;
    int sum = 0;
    int gsum = 0;
    for (int i = 0; i < n; i++) {
        sum += a * pub;
        gsum += sum;
        pub *= 10;
    }

    return gsum;
}

void slove() {
    int a, n;
    cin >> a >> n;
    cout << formation(a, n);
    scanf
}