#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <cstdio>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <unordered_map>
#include <unordered_set>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long

int max(int a, int b) {
    return a > b ? a : b;
}

int min(int a, int b) {
    return a < b ? a : b;
}

float calArea(float a, float b, float c) {
    double p = a + b + c;
    p *= 0.5;

    double A = sqrt(p * (p -a) * (p - b) * (p - c));
    return A;
}

int isTrangle(float a, float b, float c) {
    if (a + b <= c || a + c <= b || b + c <= a) return 0;
    return 1;
}

void slove() {
    float a,b,c;
    scanf("%f%f%f",&a,&b,&c);

    if (isTrangle(a, b, c)) {
        printf("%.2f", calArea(a, b, c));
    } else {
        printf("NOT TRIANGLE");
    }
}