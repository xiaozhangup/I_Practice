#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int cmp_str(const void *a, const void *b) {
    return strcmp(*(char **)a, *(char **)b);
}

int main() {
    char *s[] = {"banana", "apple", "pear"};
    qsort(s, 3, sizeof(char *), cmp_str);

    for (int i = 0; i < 3; i++)
        printf("%s\n", s[i]);
}
