#include <iostream>
#include <vector>
#include <cstdio>
#include <algorithm>

using namespace std;

void slove();

int main() {
    int T; cin >> T;

    while (T--) { 
        slove();
    }
}

#define int long long

vector<int> searchPath(vector<vector<int>> &g, int start, int end) {
    
}

void slove() {
    int n; cin >> n;
    int a, b; cin >> a >> b;

    vector<vector<int>> g(n + 1);
    for (int i = 0; i < n - 1; i++) {
        int u, v; cin >> u >> v;
        g[u].push_back(v);
        g[v].push_back(u);
    } // 种树

    
}