#include <iostream>
#include <vector>
#include <cstdio>
#include <algorithm>

using namespace std;

void slove();

int main() {
    int T; cin >> T;

    while (T--) { 
        slove();
    }
}

#define int long long


void slove() {
    int n; cin >> n;
    bool ao = true;

    vector<int> a(n);
    swap(a[0], a[n-1]);
    int maxv = 0;
    for (int i = 0; i < n; i++) {
        cin >> a[i];
        maxv = max(maxv, a[i]);
    }

    if (maxv < n) cout << "purple" << endl;
    else cout << "red" << endl;
}