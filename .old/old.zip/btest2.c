#include <stdio.h>

int find(int *p, int n, int x) {
    for (int i = 0; i < n; i++) {
        int be = p[i];
        if (be == x) {
            return 1;
        }
    }
    return 0;
}

int main() {
    int n, x,arr[100];

    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    scanf("%d", &x);
    printf("%d", find(arr, n, x));
}