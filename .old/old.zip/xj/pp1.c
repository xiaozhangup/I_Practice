#include<stdio.h>

int main()
{
    int initNum,tranNum;
    scanf("%d",&initNum);
    
    tranNum = 0;
    while (initNum) {
        tranNum = tranNum * 10 + (initNum - initNum / 10 * 10);
        initNum /= 10;
    }

    printf("%d",tranNum);
    return 0;
}