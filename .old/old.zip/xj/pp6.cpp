#include <cstdio>
#include <iostream>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long

void slove() {
    int N; cin >> N;
    for (int i = 2; i <= N; i++) {
        int n = i;
        cout << i << " = ";
        
        bool first = true;
        for (int j = 2; j * j <= n; j++) {
            while (n % j == 0) {
                if (!first) {
                    cout << " * ";
                }
                cout << j;
                n /= j;
                first = false;
            }
        }
        if (n > 1) {
            if (!first) {
                cout << " * ";
            }
            cout << n;
        }
        cout << endl;
    }
}