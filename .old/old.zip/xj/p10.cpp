#include <cstdio>
#include <string>
#include <iostream>

using namespace std;

int main() {
    int n;
    cin >> n;
    if (n < 1) {
        return 0;
    }

    if (n == 1) {
        cout << "0 1 1";
        return 0;
    }

    if (n >= 2) {
        cout << "0 1 1 ";
    }
    
    int a = 1;
    int b = 1;
    while(true) {
        int x = a + b;
        if (x > n) {
            break;
        }
        cout << x << " ";
        a = b;
        b = x;
    }
}