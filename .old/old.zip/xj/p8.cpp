#include <cstdio>
#include <string>
#include <iostream>

using namespace std;

int enums[] = {1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765, 10946, 17711, 28657, 46368, 75025};

int main() {
    double sum;
    for (int i = 0; i < 20; i++) {
        sum += (double) enums[i + 1] / (double) enums[i];
    }

    cout << sum;
}