#include <cstdio>
#include <string>
#include <iostream>

using namespace std;

int main() {
    string str;
    cin >> str;

    int max = 0;
    for (char c : str) {
        int ii = c - '0';
        if (ii > max) {
            max = ii;
        }
    }

    cout << max;
}