#include <stdio.h>
#include <iostream>

using namespace std;

int main()
{
    for (int i = 2; i <= 1000; i++) {
        long long ll = i * i - i;
        long long kaf = 1;

        int bb = i;
        while (bb) {
            bb /= 10;
            kaf *= 10;
        }

        if (ll % kaf == 0) {
            cout << i << " ";
        }
    }
}