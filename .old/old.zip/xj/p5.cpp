#include <cstdio>
#include <string>
#include <iostream>

using namespace std;

int days[] = {31, -1, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

bool isLeap(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

int main() {
    int yyyy, mm, dd;
    cin >> yyyy >> mm >> dd;

    int day = dd;
    for (int i = 0; i < mm - 1; i++) {
        int ss = days[i];
        if (ss != -1) {
            day += ss;
        } else {
            if (isLeap(yyyy)) {
                day += 29;
            } else {
                day += 28;
            }
        }
    }

    cout << day;
}