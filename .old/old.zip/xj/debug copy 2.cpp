#include <iostream>
#include <vector>
#include <string>
#include <cmath>
#include <map>
#include <set>
#include <queue>
#include <cstdio>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);

    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long

vector<vector<int>> a;
int N;

// ------------> x
// |
// |
// |
// |
// y

void fill(int last_x, int last_y, int last_num) {
    if (last_num == N * N) return;
    int i = last_num + 1;
    if (last_y == 0 && last_x != N) {
        a[last_x + 1][N] = i;
        fill(last_x + 1, N, i);
        return;
    }

    if (last_x == N && last_y != 0) {
        a[0][last_y + 1] = i;
        fill(0, last_y + 1, i);
        return;
    }

    if (last_y == 0 && last_x == N) {
        if (a[last_x + 1][last_y - 1] == 0) {
            a[last_x + 1][last_y - 1] = i;
            fill(last_x + 1, last_y - 1, i);
        } else {
            a[last_x][last_y + 1] = i;
            fill(last_x, last_y + 1, i);
        }
        return;
    }
}

void slove() {
    cin >> N;

    a.assign(N, vector<int>(N));
    int bb = N / 2;
    a[0][bb] = 1;
    N--;
    fill(bb, 0, 1);

    for (int i = 0; i < N + 1; i++) {
        for (int j = 0; j < N + 1; j++) {
            cout << a[i][j] << " ";
        }
        cout << endl;
    }
}