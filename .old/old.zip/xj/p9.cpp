#include <cstdio>
#include <string>
#include <iostream>

using namespace std;

bool check(int i) {
    string str = to_string(i);
    int sum = 0;
    for (char c : str) {
        int x = c - '0';
        sum += x * x * x;
    }

    return sum == i;
}

int main() {
    int max;
    cin >> max;
    for (int i = 100; i <= max; i++) {
        if (check(i)) {
            cout << i << " ";
        }
    }
}