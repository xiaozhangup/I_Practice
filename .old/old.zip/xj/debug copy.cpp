#include <bits/stdc++.h>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);

    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long

void slove() {
    int T; cin >> T;

    while (T--)
    {
        int n, k; cin >> n >> k;
        // 我操你妈逼，1e9的位移我操你妈
        bitset<300000> sb(k);
        for (int i = 1; i <= n; i++) {
            int x; cin >> x;
            if (i & 1) { // JI
                k = k << x;
            } else { // OU
                k = k >> x;
            }
        }
        
        cout << k % 998244353 << endl;
    }
}