#include <cstdio>
#include <iostream>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long

void slove() {
    cout << "AZ CY BX";
}