#include <cstdio>
#include <string>
#include <iostream>

using namespace std;

int days[] = {31, -1, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

bool check(int i) {
    if (i <= 3) return true;
    for (int ii = 2; ii < i; ii++) {
        if (i % ii == 0 ) return false;
    }

    return true;
}

int main() {
    int N; cin >> N;
    for (int i = 2; i <= N; i++) {
        if (check(i)) {
            cout << i << " ";
        }
    }
}