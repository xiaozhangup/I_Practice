#include<stdio.h>
#include<math.h>

double GetRadius(double c) {
    return c / 3.14 / 2.0;
}

double GetArea(double c) {
    double r=GetRadius(c);
    return 3.14*r*r;
}

int main()
{
    double c;
    scanf("%lf",&c);
    printf("%.2lf\n",GetRadius(c));
    printf("%.2lf\n",GetArea(c));
    return 0;
}