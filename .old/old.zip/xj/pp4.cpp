#include <cstdio>
#include <iostream>

using namespace std;

void slove();

int main() {
    cin.sync_with_stdio(false);
    cin.tie(NULL);
    cout.sync_with_stdio(false);
    cout.tie(NULL);

    slove();
}

#define int long long

void slove() {
    int total = 82;

    for (int a10 = 8; a10 >= 0; a10--) {
        for (int a5 = (82 - a10 * 10) / 5; a5 >= 0; a5--) {
            for (int a2 = (82 - a10 * 10 - a5 * 5) / 2; a2 >= 0; a2--) {
                int b10 = a10 + 1;
                int b5 = a5 + 1;
                int b2 = a2 + 1;
                int b1 = 82 - a10 * 10 - a5 * 5 - a2 * 2 + 1;
                if (b10 + b5 + b2 + b1 == 40) {
                    cout << b10 << " " << b5 << " " << b2 << " " << b1 << endl;
                }
            }
        }
    }
}