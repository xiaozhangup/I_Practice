void Delete(struct AddressBook addr[], int n, int pos)
{
    for (int i = pos; i < n - 1; i++)
    {
        addr[i] = addr[i + 1];
    }
}