#include <cstdio>
#include <string>
#include <iostream>

using namespace std;

int main() {
    int a = 0, b = 0, c = 0;
    for (int i = 0; i < 10; i++) {
        int x;
        cin >> x;

        if (x > 0) {
            a++;
        } else if (x < 0) {
            b++;
        } else {
            c++;
        }
    }

    printf("%d %d %d", a, b, c);
}