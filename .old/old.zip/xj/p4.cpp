#include <cstdio>
#include <string>
#include <iostream>

using namespace std;

int main() {
    int index = 0;
    int end; cin >> end;
    for (int i = 100; i <= end; i++) {
        if (i % 5 != 0) continue;
        string str = to_string(i);
        int sum = 0;
        for (char c : str) {
            int nn = c - '0';
            sum += nn;
        }

        if (sum != 9) continue;

        if (index == 5) {
            cout << endl;
            index = 0;
        }
        index++;
        cout << i << " ";
    }
}