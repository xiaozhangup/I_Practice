#include <stdio.h>

int main() {
    int score1, score2, score3;
    scanf("%d%d%d", &score1, &score2, &score3);

    if (score1 < 60 || score2 < 60 || score3 < 60) {
        printf("Non");
    } else {
        int avg = (score1 + score2 + score3) / 3;
        switch (avg / 10) {
            case 10:
            case 9:
                printf("甲");
                break;
            case 8:
                printf("乙");
                break;
            case 7:
                printf("丙");
                break;
            default:
                printf("Non");
        }
    }

    return 0;
}
