#include <stdio.h>

int main() {
    int arr[100];
    int index = 0;
    char str[1000];
    int indec = 0;
    int bi = 0;
    int baf = 0;

    fgets(str, sizeof(str), stdin);

    while (str[index] != '\0') {
        if (str[index] >= '0' && str[index] <= '9') {
            indec = indec * 10 + (str[index] - '0');
            baf = 1;
        } else {
            if (baf) {
                arr[bi++] = indec;
                indec = 0;
                baf = 0;
            }
        }
        index++;
    }

    if (baf) {
        arr[bi++] = indec;
    }

    printf("%d\n", bi);

    for (int i = 0; i < bi; i++) {
        printf("%d", arr[i]);
        if (i < bi - 1) printf(" ");
    }

    return 0;
}
